package InterThreadCommunication;

public class Consumer implements Runnable{

	//2
	private Thread t;
	private stock s;
	private boolean bRun;
	
	public Consumer(stock s) {
		this.s = s;
		this.bRun = true;
		//3
		this.t = new Thread(this);
	}
	
	//4
	public void run() {
		while(bRun)
			s.Consumer();
	}
	
	//5
	public Thread getT() {
		return t;
	}

	public void setbRun(boolean bRun) {
		this.bRun = bRun;
	}
	
	

}
