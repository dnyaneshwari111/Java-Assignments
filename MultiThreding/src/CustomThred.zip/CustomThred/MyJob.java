package CustomThred;

public class MyJob implements Runnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable r=new MyJob();
		r.run();

	}

	@Override
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.println(i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
