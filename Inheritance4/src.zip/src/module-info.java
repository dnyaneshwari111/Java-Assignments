/**
 * 
 */
/**
 * 
 */
module Inheritance4 {
}