package app;

import staff.Administration;
import staff.Programmer;
import staff.SalesManager;

public class EmpDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SalesManager s1=new SalesManager("Dnyanuu",22,101,50000,10000,5000);
		s1.display();
		
		Programmer p1=new Programmer("Rucha",21,102,20000,1000,"ERP",6,5000);
		p1.display();
		Administration a1=new Administration("Puja",21,103,60000,8000);
		a1.display();
		
		//(String name, int age, int empId, double BasicSalary,double salesTarget,,String ProjectTitle,int extraHours,double chargesPerHr)
	}

}
